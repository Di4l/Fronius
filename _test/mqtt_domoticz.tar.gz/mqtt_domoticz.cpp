//-----------------------------------------------------------------------------
#include <iostream>
#include <unistd.h>

#include "mqtt_domoticz.h"
//-----------------------------------------------------------------------------
uint32_t MqttDomoticz::m_uiInstances = 0;
//-----------------------------------------------------------------------------

MqttDomoticz::MqttDomoticz(const char* _i, const char* _h, const int _p)
	: mosqpp::mosquittopp(_i), m_host(_h), m_id(_i), m_port(_p)
	, m_keepalv(120), onMessage(nullptr), onSubscribe(nullptr)
{
	if(!m_uiInstances)
		mosqpp::lib_init();
	++m_uiInstances;

	connect_async(m_host.c_str(), m_port, m_keepalv);
	loop_start();
}
//-----------------------------------------------------------------------------

MqttDomoticz::~MqttDomoticz()
{
	loop_stop(true);
	disconnect();
	if(!--m_uiInstances)
		mosqpp::lib_cleanup();
}
//-----------------------------------------------------------------------------

void MqttDomoticz::on_connect(int rc)
{
	if(rc == 0)
	{
		char c_topic[256];
		sprintf(c_topic, "domoticz/out/%s/commands", m_id.c_str());
		subscribe(NULL, c_topic);
	}
}
//-----------------------------------------------------------------------------

void MqttDomoticz::on_message(const mosquitto_message* mssg)
{
	if(onMessage)
		onMessage(mssg->topic, reinterpret_cast<const char*>(mssg->payload));
}
//-----------------------------------------------------------------------------

void MqttDomoticz::on_subscribe(int mid, int qos_count, const int* granted_qos)
{
	if(onSubscribe)
		onSubscribe(mid, qos_count, granted_qos);
}
//-----------------------------------------------------------------------------

bool MqttDomoticz::sendMessage(const char* _mssg)
{
	std::cout << "MqttDomoticz::sendMessage()" << std::endl;
	char c_topic[256];
	sprintf(c_topic, "domoticz/in/%s/sensors", m_id.c_str());
	std::cout << "call public(NULL, " << c_topic << "," << strlen(_mssg) << ", " << _mssg << ", 1, false)" << std::endl;
	return publish(NULL, c_topic, strlen(_mssg), _mssg, 1, false) == MOSQ_ERR_SUCCESS;
}
//-----------------------------------------------------------------------------
