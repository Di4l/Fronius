//-----------------------------------------------------------------------------
#ifndef __MQTT_DOMOTICZ_H__
#define __MQTT_DOMOTICZ_H__
//-----------------------------------------------------------------------------
#include <mosquittopp.h>
#include <string.h>
//-----------------------------------------------------------------------------

typedef void (*v_dom_cc)(const char*, const char*);
typedef void (*v_dom_iipci)(int, int, const int*);
//-----------------------------------------------------------------------------

class MqttDomoticz : public mosqpp::mosquittopp
{
private:
	static uint32_t m_uiInstances;

	std::string m_host;
	std::string m_id;
	int         m_port;
	int         m_keepalv;

protected:
	void on_connect(int rc);
	void on_message(const mosquitto_message* mssg);
	void on_subscribe(int mid, int qos_count, const int* granted_qos);

public:
	MqttDomoticz(const char* _i, const char* _h = "localhost", const int _p = 1883);
	~MqttDomoticz();

	bool sendMessage(const char* _mssg);

	v_dom_cc    onMessage;
	v_dom_iipci onSubscribe;
};
//-----------------------------------------------------------------------------
#endif //__MQTT_DOMOTICZ_H__
